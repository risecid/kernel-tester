# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=Appender-v4 for Redmi 5A by saurabh6377 @ xda-developers
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=0
device.name1=riva
device.name2=Redmi 5A
device.name3=
device.name4=
device.name5=
supported.versions=
supported.patchlevels=
'; } # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

## AnyKernel install
split_boot;

flash_boot;

# Boot image patching
dir=/tmp/anykernel
bb=$dir/tools/busybox

cd $dir;
  if [ ! -f boot-new.img ]; then
    abort "No repacked image found to flash. Aborting...";
  fi;

  $bb printf '\x30\x83\x19\x89\x64' | $bb dd of=boot-new.img ibs=4096 oflag=append conv=sync,notrunc;
  mv -f boot-new.img boot-new-patched.img 2>/dev/null;

  if [ "$(wc -c < boot-new-patched.img)" -gt "$(wc -c < boot.img)" ]; then
    abort "New image larger than boot partition. Aborting...";
  fi;

  dd if=boot-new-patched.img of=$block;
## end install

